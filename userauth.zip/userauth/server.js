if (process.env.NODE_ENV !== 'production') {
  require('dotenv').config();
}

const express = require('express');
const app = express();
const bcrypt = require('bcrypt');
const passport = require('passport');
const initializePassport = require('./passport-config');
const flash = require('express-flash');
const session = require('express-session');
const bodyparser = require('body-parser');

initializePassport(
  passport,
  (email) => users.find((user) => user.email === email),
  (id) => users.find((user) => user.id === id)
);

const users = [];
app.use(express.urlencoded({ extended: false }));
app.use(flash());
app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false, // We wont resave the session variable if nothing is changed
    saveUninitialized: false,
  })
);
app.use(passport.initialize());
app.use(passport.session());
app.use(bodyparser.urlencoded({ extended: true }));
// Configuring the register post functionality
app.post(
  '/login',
  checkNotAuthenticated,
  passport.authenticate('local', {
    successRedirect: '/',
    failureRedirect: '/login',
    failureFlash: true,
  })
);
let nic = 0;
let year = '';
var sex = '';
var serialNum = 0;
app.post('/register', checkNotAuthenticated, async (req, res) => {
  let nicnum = req.body.nic;
  year = '19' + nicnum.substr(0, 2);
  serialNum = parseInt(nicnum.substr(2, 3));

  if (serialNum > 500) {
    sex = 'female';
    console.log(sex);
  } else {
    sex = 'male';
    console.log(sex);
  }

  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    users.push({
      id: Date.now().toString(),
      name: req.body.name,
      email: req.body.email,
      nic: req.body.nic,
      password: hashedPassword,
    });
    console.log(users); // Display newly registered in the console
    res.redirect('/login');
  } catch (e) {
    console.log(e);
    res.redirect('/register');
  }
});

//routes
app.get('/', checkAuthenticated, (req, res) => {
  res.render('index.ejs', {
    name: req.user.name,
    year: year,
    sex: sex,
  });
});
app.get('/login', checkNotAuthenticated, (req, res) => {
  res.render('login.ejs');
});

app.get('/register', checkNotAuthenticated, (req, res) => {
  res.render('register.ejs');
});

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/login');
}

function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect('/');
  }
  next();
}

app.listen(3000);
// end root
